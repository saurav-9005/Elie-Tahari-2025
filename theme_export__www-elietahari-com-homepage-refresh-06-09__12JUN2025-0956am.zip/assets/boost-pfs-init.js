var boostAI_DefaultSortingValue={sorting:"Sorting",sorting_best_selling:"Best Selling",sorting_featured:"Featured",sorting_heading:"Sorting",sorting_manual:"Manual",sorting_relevance:"Relevance",sorting_created_ascending:"Created Ascending",sorting_created_descending:"Created Descending",sorting_date_ascending:"Date Ascending",sorting_date_descending:"Date Descending",sorting_published_descending:"Published Descending",sorting_published_ascending:"Published Ascending",sorting_price_ascending:"Price Ascending",sorting_price_descending:"Price Descending",sorting_sale_ascending:"% Off",sorting_sale_descending:"% Off, Low to High",sorting_title_ascending:"Title Ascending",sorting_title_descending:"Title Descending"};try{if("undefined"!=typeof boostPFSThemeConfig&&boostPFSThemeConfig.hasOwnProperty("label"))for(var key in boostPFSThemeConfig.label){if(boostPFSThemeConfig.label.hasOwnProperty(key)&&"string"==typeof boostPFSThemeConfig.label[key])-1!==(value=boostPFSThemeConfig.label[key].toLowerCase()).indexOf("translation missing")&&void 0!==boostAI_DefaultSortingValue[key]&&(boostPFSThemeConfig.label[key]=boostAI_DefaultSortingValue[key])}if("undefined"!=typeof bcSfFilterConfig&&bcSfFilterConfig.hasOwnProperty("label"))for(var key in bcSfFilterConfig.label){var value;if(bcSfFilterConfig.label.hasOwnProperty(key)&&"string"==typeof bcSfFilterConfig.label[key])-1!==(value=bcSfFilterConfig.label[key].toLowerCase()).indexOf("translation missing")&&void 0!==boostAI_DefaultSortingValue[key]&&(bcSfFilterConfig.label[key]=boostAI_DefaultSortingValue[key])}}catch(e){console.log("Patch defaultSortingValue error")}

var boostPFS = new BoostPFS();
boostPFS.init(); 
if (typeof boostPFSConfig != 'undefined' 
	&& typeof boostPFSConfig.general != 'undefined' 
	&& typeof boostPFSConfig.general.isInitFilter != 'undefined' 
	&& boostPFSConfig.general.isInitFilter === true) { 
	boostPFS.initFilter(); 
} 
BoostPFS.jQ(window).on('load', function(){
	boostPFS.initSearchBox();
	false && boostPFS.initAnalytics();
});